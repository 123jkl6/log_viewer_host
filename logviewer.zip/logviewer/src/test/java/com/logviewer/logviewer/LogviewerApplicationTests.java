package com.logviewer.logviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogviewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
