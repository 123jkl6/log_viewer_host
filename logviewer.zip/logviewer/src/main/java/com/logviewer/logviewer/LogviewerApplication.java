package com.logviewer.logviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogviewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogviewerApplication.class, args);
	}

}
